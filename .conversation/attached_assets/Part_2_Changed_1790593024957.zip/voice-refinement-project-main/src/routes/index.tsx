import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Amazing Grace Studio — Urdu & Hindi Dubbing, Voiceover, Localization" },
    { name: "description", content: "Premium Urdu and Hindi dubbing, voiceover and localization for global media brands, creators and ministries." },
    { property: "og:title", content: "Amazing Grace Studio — Urdu & Hindi Dubbing" },
    { property: "og:description", content: "Premium Urdu and Hindi dubbing, voiceover and localization." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  return (
    <iframe title="Amazing Grace Studio" src="/legacy/index.html" className="block h-dvh w-full border-0" />
  );
}
