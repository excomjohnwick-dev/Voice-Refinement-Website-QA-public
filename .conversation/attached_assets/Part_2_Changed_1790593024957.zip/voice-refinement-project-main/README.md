# Voice Refinement Project

PART 2 — VOICE SAMPLES, BROADCAST TV, CONTACT FORM & SOCIAL MEDIA

Continue modifying the EXISTING website.

IMPORTANT:

Do NOT rebuild the website.

Do NOT break existing components or functionality.

Preserve the current design, responsive behavior, animations, and navigation.

Only implement the changes specified below.

1. VOICE SAMPLES — FULL LENGTH

Update the Voice Samples section.

Requirements:

Keep every voice sample at its ORIGINAL/FULL LENGTH.

Do NOT trim.

Do NOT shorten.

Do NOT replace the current audio files unless necessary.

Preserve the existing playback functionality.

2. REMOVE ARTIST / NARRATOR NAMES

Remove all artist/narrator names from the visible Voice Samples interface.

This includes:

Voice sample cards

Audio player labels

Headings

Descriptions

Metadata

Any visible artist/narrator attribution

The voice samples should remain available and playable, but the artist/narrator names must no longer be displayed.

3. UPDATE VOICE ARTIST CATEGORIES

Update the language/category information exactly as follows:

Asher → Urdu Male

Khurram → Hindi

Arshia → Urdu

Sadaf → Hindi

Do not invent additional categories or modify these values.

4. BROADCAST TV

Under the Broadcast TV section, completely remove these entries:

PTV

Zee

Star

Ensure they are removed from:

Cards

Lists

Logos

Text

Filters/categories

Any associated data structures or rendered components

Do not leave broken placeholders after removal.

5. CONTACT / EMAIL FORM

The current contact/email form is not working.

Fix the form so that:

Users can successfully submit the form.

Required fields work correctly.

Validation works correctly.

Submission does not fail silently.

The user receives clear success/error feedback.

The existing visual design of the form is preserved.

The form remains fully responsive.

Connect the form to the project’s existing email/contact submission system where available.

Do not create unnecessary UI changes.

6. LINKEDIN

For LinkedIn:

Keep only the actual LinkedIn social media link active.

Remove unnecessary LinkedIn-related buttons, duplicates, placeholders, or additional functionality.

Ensure the remaining LinkedIn link opens correctly.

7. REMOVE PHONE NUMBER COMPLETELY

Remove the contact phone number from the ENTIRE website.

Search every page and component, including:

Header

Footer

Contact Page

Contact section

CTA buttons

Forms

Mobile navigation

Popups/modals

Any other visible or hardcoded content

There must be NO contact phone number displayed anywhere after this update.

Do not remove email or social media contact methods unless specifically requested.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/5cef61a0-15a6-409d-ae00-3aac6f69a51f).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
